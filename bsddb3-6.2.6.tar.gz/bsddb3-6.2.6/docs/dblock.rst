DBLock
------

Read :Oracle:`Oracle documentation <programmer_reference/index.html>`
for better understanding.

The DBLock objects have no methods or attributes. They are just opaque
handles to the lock in question.

They are managed via DBEnv methods.

